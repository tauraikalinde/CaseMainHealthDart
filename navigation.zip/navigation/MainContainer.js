import * as React from 'react';
import { View, Text } from 'react-native';
import { Ionicons } from 'react-native-vector-icons';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';


//Screens
import HomeScreen from './screens/HomeScreen'
import ConsultScreen from './screens/ConsultsScreen'
import OrdersScreen from './screens/OrdersScreen'
import ProfileScreen from './screens/ProfileScreen' 

//Screen Names

const homeName = 'Home';
const consultName = 'Consult';
const ordersName = 'Orders';
const profileName = 'Profile';

const Tab = createBottomTabNavigator();


export default function MainContainer(){
    return(
        <NavigationContainer>
            <Tab.Navigator
            InitialRouteName={homeName}
            screenOptions={({route}) => ({
                tabBarIcon: ({ focused, color, size  }) => {
                    let iconName;
                    let rn = route.name;

                    if(rn ===homeName){
                        iconName = focused ? 'home' : 'home-outline';
                    }else if (rn === consultName) {
                        iconName = focused ? 'Consult' : 'Consult-outline';
                    }else if (rn === ordersName) {
                        iconName = focused ? 'Orders' : 'Orders-outline';
                    }else if (rn === profileName) {
                        iconName = focused ? 'Profile' : 'Profile-outline';
                    }

                    return <Ionicons name={iconName} size={size} color={color}/>




                },
            })}>

            <Tab.Screen name={homeName} component={HomeScreen}/>
            <Tab.Screen name={consultName} component={consultScreen}/>
            <Tab.Screen name={orderName} component={ordersScreen}/>
            <Tab.Screen name={profileName} component={profileScreen}/>
            </Tab.Navigator>
        </NavigationContainer>
   
    );
}